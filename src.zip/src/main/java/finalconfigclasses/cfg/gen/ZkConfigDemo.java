package finalconfigclasses.cfg.gen;

import java.util.HashMap;

import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.test.TestingServer;

import finalconfigclasses.cfg.zk.ZkConfigManager;

/**
 * Small, self-contained, runnable demonstration of the ZooKeeper-backed
 * persistence and cluster-wide reload feature described in the project
 * README. It replaces the old ad-hoc Test1..Test12/TestAll demo classes,
 * which were tied to the removed file-based XML persistence model.
 *
 * What it shows:
 * <ol>
 *   <li>Two independent {@link CacheConfigImpl} instances - "peerA" and
 *       "peerB" - are created, each pointed at the same znode path (as if
 *       they were the same logical config bean running in two different
 *       JVMs across a cluster).</li>
 *   <li>Both are registered for watching via {@code ZkConfigManager.watch(...)}.</li>
 *   <li>peerA calls {@code save()}.</li>
 *   <li>A moment later, peerB's in-memory state has been updated
 *       automatically (via its ZooKeeper watcher calling {@code load()}
 *       behind the scenes) - with no direct call between peerA and peerB.</li>
 * </ol>
 *
 * This demo spins up an embedded, in-process ZooKeeper server (via
 * curator-test's {@code TestingServer}) so it can be run with no external
 * infrastructure. In a real deployment, every peer would instead point at
 * the same real ZooKeeper ensemble connect string.
 *
 * Run with:
 * <pre>
 * mvn -q exec:java -Dexec.mainClass=finalconfigclasses.cfg.gen.ZkConfigDemo
 * </pre>
 */
public final class ZkConfigDemo {

	public static void main(String[] args) throws Exception {
		TestingServer zkServer = new TestingServer();
		try {
			String connectString = zkServer.getConnectString();
			System.out.println("Embedded ZooKeeper started at " + connectString);

			// In a real multi-JVM deployment each peer would independently call
			// ZkConfigManager.getInstance().start(connectString) using the SAME
			// real ZooKeeper ensemble connect string - there is no other
			// coordination needed between peers.
			ZkConfigManager manager = ZkConfigManager.getInstance();
			manager.start(connectString, new ExponentialBackoffRetry(1000, 3), 15000);

			String propertiesRoot = "/finalconfigclasses/demo";

			HashMap<String, Object> defaults = new HashMap<String, Object>();
			defaults.put("cacheSize", 100);
			defaults.put("cachePolicy", "LRU");

			// "peerA": the instance that will make the change and call save().
			CacheConfigImpl peerA = new CacheConfigImpl(defaults, propertiesRoot,
					"demo-lock", null, "demo-doc", null, null);

			// "peerB": simulates a second JVM in the cluster watching the exact
			// same znode; it never talks to peerA directly.
			CacheConfigImpl peerB = new CacheConfigImpl(defaults, propertiesRoot,
					"demo-lock", null, "demo-doc", null, null);

			manager.watch(peerA);
			manager.watch(peerB);

			System.out.println("peerB before change: cacheSize=" + peerB.getCacheSize()
					+ ", cachePolicy=" + peerB.getCachePolicy());

			peerA.setCacheSize(500);
			peerA.setCachePolicy("LFU");
			peerA.save();
			System.out.println("peerA saved: cacheSize=" + peerA.getCacheSize()
					+ ", cachePolicy=" + peerA.getCachePolicy());

			// Give the ZooKeeper watch notification + background reload a moment
			// to arrive - in a real application you'd instead rely on
			// PropertyChangeListener/NodeChangeListener callbacks rather than
			// polling/sleeping.
			long deadline = System.currentTimeMillis() + 10000;
			while (System.currentTimeMillis() < deadline && peerB.getCacheSize() != 500) {
				Thread.sleep(100);
			}

			System.out.println("peerB after remote change propagated: cacheSize="
					+ peerB.getCacheSize() + ", cachePolicy=" + peerB.getCachePolicy());

			if (peerB.getCacheSize() == 500 && "LFU".equals(peerB.getCachePolicy())) {
				System.out.println("SUCCESS: peerB picked up peerA's change via ZooKeeper watch.");
			} else {
				System.out.println("peerB did not observe the change in time - check ZooKeeper connectivity.");
			}

			manager.unwatch(peerA);
			manager.unwatch(peerB);
			manager.shutdown();
		} finally {
			zkServer.close();
		}
	}

	private ZkConfigDemo() {
	}
}
