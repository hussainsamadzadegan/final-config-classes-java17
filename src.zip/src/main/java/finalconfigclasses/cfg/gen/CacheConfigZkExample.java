package finalconfigclasses.cfg.gen;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import finalconfigclasses.bean.BeanUpdateEvent;
import finalconfigclasses.bean.BeanUpdateFailedException;
import finalconfigclasses.bean.BeanUpdateListener;
import finalconfigclasses.bean.BeanUpdateRejectedException;
import org.apache.curator.retry.ExponentialBackoffRetry;

import finalconfigclasses.cfg.zk.ZkConfigManager;

/**
 * Minimal example: connect to a real, already-running ZooKeeper ensemble,
 * load a CacheConfigImpl from it, change a couple of properties, and save
 * it back.
 */
public class CacheConfigZkExample {

    public static void main(String[] args) throws Exception {

        // 1. Point at your running ZooKeeper ensemble (comma-separated
        //    host:port list for a multi-node cluster).
        String connectString = "localhost:2181";

        ZkConfigManager manager = ZkConfigManager.getInstance();
        manager.start(connectString, new ExponentialBackoffRetry(1000, 3), Integer.MAX_VALUE);

        // 2. Defaults must contain an entry for every attribute declared on
        //    CacheConfigImpl (cacheSize, cachePolicy) - used as fallback
        //    values when a given attribute hasn't been explicitly set yet.
        HashMap<String, Object> defaults = new HashMap<String, Object>();
        defaults.put("cacheSize", 100);
        defaults.put("cachePolicy", "LRU");

        // 3. Construct the bean. propertiesFile is the ZK root path,
        //    document is a logical sub-namespace, name/keyPrefix are null
        //    here since this is a standalone top-level bean (no parent).
        CacheConfigImpl cacheConfig = new CacheConfigImpl(
                defaults,
                "/app/config",              // propertiesFile -> ZK root path
                "cache-config-lock",         // lockID
                new ReentrantReadWriteLock(),// propertiesLock
                "prod",                      // document
                null,                        // name
                null                         // keyPrefix
        );
        cacheConfig.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("propertyChange: "+evt.getPropertyName() + " old value: " + evt.getOldValue() + " new value: " + evt.getNewValue());
            }
        });
        cacheConfig.addBeanUpdateListener(new BeanUpdateListener() {

            @Override
            public void prepareUpdate(BeanUpdateEvent event) throws BeanUpdateRejectedException {
                System.out.println("prepareUpdate"+event.toString());
            }

            @Override
            public void activateUpdate(BeanUpdateEvent event) throws BeanUpdateFailedException {
                System.out.println("activateUpdate"+event.toString());
            }

            @Override
            public void rollbackUpdate(BeanUpdateEvent event) {
                System.out.println("rollbackUpdate"+event.toString());
            }
        });

        // 4. Load current state from ZooKeeper (creates the znode with
        //    defaults if it doesn't exist yet, since this uses the
        //    "flexible" generated load()).
        cacheConfig.load();
        manager.watch(cacheConfig);
        cacheConfig.save();

        System.out.println("Loaded from ZooKeeper:");
        System.out.println("  cacheSize   = " + cacheConfig.getCacheSize());
        System.out.println("  cachePolicy = " + cacheConfig.getCachePolicy());

        for(int i = 0; i < 10; i++) {
            // 5. Change some properties.
            cacheConfig.setCacheSize(Math.random() > 0.5 ? 2048 : 1024);
            cacheConfig.setCachePolicy(Math.random() > 0.5 ? "LFU" : "LRU");


            // 6. Persist the changes back to ZooKeeper.
            cacheConfig.save();
        }

        System.out.println("Saved to ZooKeeper:");
        System.out.println("  cacheSize   = " + cacheConfig.getCacheSize());
        System.out.println("  cachePolicy = " + cacheConfig.getCachePolicy());

        // 7. (Optional) Watch this bean so that if ANY other peer in the
        //    cluster changes the same znode, this instance automatically
        //    reloads.


        Thread.sleep(Long.MAX_VALUE);

        // ... keep the app running to receive updates, or when done:
        // manager.unwatch(cacheConfig);
        // manager.shutdown();
    }
}