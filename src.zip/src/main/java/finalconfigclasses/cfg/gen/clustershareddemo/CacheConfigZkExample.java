package finalconfigclasses.cfg.gen.clustershareddemo;

import finalconfigclasses.cfg.Registry;
import finalconfigclasses.cfg.zk.ZkConfigManager;
import finalconfigclasses.cfg.gen.BankConfigImpl;
import finalconfigclasses.cfg.gen.CacheConfigImpl;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class CacheConfigZkExample {

    private static final AtomicInteger nodeCounter = new AtomicInteger(1);

    public static void main(String[] args) throws Exception {
        String zkConnect = "localhost:2181";
        String propertiesFile = "/app/config";

        ZkConfigManager.getInstance().start(zkConnect);

        // شبیه‌سازی ۳ نود جداگانه
        new Thread(() -> runNode("node1", propertiesFile), "Node-1").start();
        Thread.sleep(1000); // کمی فاصله برای جلوگیری از race
        new Thread(() -> runNode("node2", propertiesFile), "Node-2").start();
        Thread.sleep(1000);
        new Thread(() -> runNode("node3", propertiesFile), "Node-3").start();
    }

    private static void runNode(String nodeId, String propertiesFile) {
        try {
            System.out.println("\n=== 🚀 شروع نود: " + nodeId + " ===");

            // BankConfig مشترک (اما listener جدا)
            BankConfigImpl bank = createBankConfig(nodeId, propertiesFile);
            bank.save();
            bank.addPropertyChangeListener(evt -> {
                System.out.printf("[%s] 🔥 PropertyChange: %s = %s -> %s%n",
                        nodeId, evt.getPropertyName(), evt.getOldValue(), evt.getNewValue());
            });
            // CacheConfig کاملاً ایزوله با document جدا
            CacheConfigImpl cache = createCacheConfig(nodeId, bank, propertiesFile);

            bank.addCacheConfigs(cache);
            ZkConfigManager.getInstance().watch(bank);

            // ثبت listener خاص این نود
            cache.addPropertyChangeListener(evt -> {
                System.out.printf("[%s] 🔥 PropertyChange: %s = %s -> %s%n",
                        nodeId, evt.getPropertyName(), evt.getOldValue(), evt.getNewValue());
            });

            // لود اولیه
            cache.load();

            System.out.println("[" + nodeId + "] CacheSize اولیه: " + cache.getCacheSize());

            // تغییر و سیو
            int newSize = 5000 + (int)(Math.random() * 3000);
            cache.setCacheSize(newSize);
            System.out.println("[" + nodeId + "] CacheSize بعد تغییر: " + cache.getCacheSize());

            cache.save();
            System.out.println("[" + nodeId + "] ✅ سیو شد → " + getZnodePath(cache));

            Thread.sleep(Long.MAX_VALUE); // برای مشاهده تغییرات

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static BankConfigImpl createBankConfig(String nodeId,String propertiesFile) {
        HashMap defaultProperties = new HashMap();
        defaultProperties.put("tmpFolder", "home");
        return new BankConfigImpl(defaultProperties, propertiesFile, null, null, nodeId + "-cache",   // ← جداسازی کلیدی
                null, null);
    }

    private static CacheConfigImpl createCacheConfig(String nodeId, BankConfigImpl parent, String propertiesFile) {
        HashMap<String, Object> defaults = new HashMap<>();
        defaults.put("cacheSize", 1000);
        defaults.put("cachePolicy", "300");

        return new CacheConfigImpl(
                defaults,
                parent,
                propertiesFile,
                null,
                null,
                nodeId + "-cache",   // ← جداسازی کلیدی
                "cache",
                null
        );
    }

    private static String getZnodePath(CacheConfigImpl cache) {
        try {
            return finalconfigclasses.cfg.zk.ZkConfigStore.buildZnodePath(
                    cache._getPropertiesFile(),
                    cache._getDocument(),
                    cache._getXPath()
            );
        } catch (Exception e) {
            return "ERROR";
        }
    }
}