package finalconfigclasses.cfg.zk;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.curator.framework.CuratorFramework;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.data.Stat;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import finalconfigclasses.cfg.ConfigException;

/**
 * Persists/loads the simple attributes of a single config bean as the data
 * payload of a single ZooKeeper znode, addressed by the bean's
 * {@code (propertiesFile, document, xpath)} triple - i.e. what used to be
 * "the file + xpath into the shared XML document" now becomes "the znode
 * path". This is the ZooKeeper equivalent of the old
 * {@code finalconfigclasses.util.XMLUtils} load/save helpers, and is what
 * the code generator wires the generated config classes' {@code load()}/
 * {@code save()} methods up to (see the flexible/rigid load/save Velocity
 * templates).
 */
public final class ZkConfigStore {

	private static final XStream XSTREAM = createXStream();

	private static final Pattern NAME_ATTR = Pattern.compile("\\[@name='([^']*)'\\]");

	private ZkConfigStore() {
	}

	/**
	 * Builds the fully qualified, ZooKeeper-legal znode path for a config
	 * bean given its properties root, logical document and xpath (as
	 * produced by {@code ConfigBean._getXPath()}).
	 *
	 * The xpath produced by the framework looks like
	 * {@code bank-ear/cache-config[@name='jasperReportTemplateCacheConfig']};
	 * the {@code [@name='...']} selector syntax (borrowed from the original
	 * XPath-based implementation) is translated into a plain path segment,
	 * e.g. {@code /bank-ear/cache-config/jasperReportTemplateCacheConfig}.
	 */
	public static String buildZnodePath(String rootPath, String document, String xpath) {
		StringBuilder sb = new StringBuilder();
		if (rootPath != null && rootPath.length() > 0) {
			sb.append('/').append(normalizeSegment(rootPath));
		}
		if (document != null && document.length() > 0) {
			sb.append('/').append(normalizeSegment(document));
		}
		if (xpath != null && xpath.length() > 0) {
			sb.append('/').append(sanitizeXPath(xpath));
		}
		String path = sb.toString().replaceAll("/{2,}", "/");
		if (path.length() == 0) {
			path = "/";
		}
		if (!path.startsWith("/")) {
			path = "/" + path;
		}
		if (path.length() > 1 && path.endsWith("/")) {
			path = path.substring(0, path.length() - 1);
		}
		return path;
	}

	private static String normalizeSegment(String s) {
		String t = s.trim();
		while (t.startsWith("/")) {
			t = t.substring(1);
		}
		while (t.endsWith("/")) {
			t = t.substring(0, t.length() - 1);
		}
		return t;
	}

	private static String sanitizeXPath(String xpath) {
		Matcher m = NAME_ATTR.matcher(xpath);
		return m.replaceAll("/$1");
	}

	/**
	 * Reads back the attribute snapshot for one config bean.
	 *
	 * @param createPathIfAbsent
	 *            "flexible" mode: if the znode does not exist yet, it is
	 *            created (empty) and an empty, "not loaded" snapshot is
	 *            returned instead of failing - mirroring the old
	 *            {@code XMLUtils.loadOrCreateDocument(file, true)} behavior.
	 *            When {@code false} ("rigid" mode) a missing znode results in
	 *            a {@link ConfigException}.
	 */
	public static ZkAttrSnapshot loadAttributes(CuratorFramework client, String rootPath, String document,
			String xpath, boolean createPathIfAbsent) throws Exception {
		String znodePath = buildZnodePath(rootPath, document, xpath);
		byte[] data;
		try {
			data = client.getData().forPath(znodePath);
		} catch (KeeperException.NoNodeException nne) {
			if (!createPathIfAbsent) {
				throw new ConfigException("ZooKeeper node not found: " + znodePath, nne);
			}
			try {
				client.create().creatingParentsIfNeeded().forPath(znodePath, new byte[0]);
			} catch (KeeperException.NodeExistsException raceIgnored) {
				// another peer created it concurrently - fine, fall through with empty snapshot
			}
			return new ZkAttrSnapshot();
		}
		if (data == null || data.length == 0) {
			return new ZkAttrSnapshot();
		}
		Object obj = XSTREAM.fromXML(new String(data, StandardCharsets.UTF_8));
		ZkAttrSnapshot snap = (ZkAttrSnapshot) obj;
		snap.setLoaded(true);
		return snap;
	}

	/**
	 * Writes the attribute snapshot for one config bean.
	 *
	 * @param createPathIfAbsent
	 *            "flexible" mode: creates the znode (and any missing parent
	 *            znodes) if it does not exist yet. In "rigid" mode a missing
	 *            znode results in a {@link ConfigException}.
	 */
	public static void saveAttributes(CuratorFramework client, String rootPath, String document, String xpath,
			Map<String, Object> values, Map<String, Boolean> setFlags, boolean createPathIfAbsent) throws Exception {
		String znodePath = buildZnodePath(rootPath, document, xpath);
		ZkAttrSnapshot snap = new ZkAttrSnapshot(values, setFlags);
		byte[] data = XSTREAM.toXML(snap).getBytes(StandardCharsets.UTF_8);

		Stat stat = client.checkExists().forPath(znodePath);
		if (stat == null) {
			if (!createPathIfAbsent) {
				throw new ConfigException("ZooKeeper node not found: " + znodePath);
			}
			try {
				client.create().creatingParentsIfNeeded().forPath(znodePath, data);
			} catch (KeeperException.NodeExistsException race) {
				// created concurrently by another peer between checkExists() and create() - just set the data
				client.setData().forPath(znodePath, data);
			}
		} else {
			client.setData().forPath(znodePath, data);
		}
	}

	private static XStream createXStream() {
		XStream xs = new XStream(new StaxDriver());
		XStream.setupDefaultSecurity(xs);
		xs.allowTypesByWildcard(new String[] {
				"finalconfigclasses.cfg.zk.**",
				"java.lang.*",
				"java.util.*"
		});
		xs.alias("attr-snapshot", ZkAttrSnapshot.class);
		return xs;
	}
}
