package finalconfigclasses.cfg.zk;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.CuratorCache;
import org.apache.curator.framework.recipes.cache.CuratorCacheListener;
import org.apache.curator.retry.ExponentialBackoffRetry;

import finalconfigclasses.cfg.ConfigBean;
import finalconfigclasses.cfg.ConfigException;
import finalconfigclasses.cfg.misc.UnwatchAllVisitor;
import finalconfigclasses.cfg.misc.WatchAllVisitor;

/**
 * Singleton that owns the shared {@link CuratorFramework} ZooKeeper client
 * and coordinates cluster-wide configuration reload:
 * <ol>
 *   <li>Every JVM ("peer") in the cluster starts a {@code ZkConfigManager}
 *       pointed at the same ZooKeeper ensemble.</li>
 *   <li>Each peer calls {@link #watchSubtree(ConfigBean)} once, after
 *       constructing its config bean tree, to register a watcher on every
 *       bean's znode.</li>
 *   <li>Whenever any peer calls {@code configBean.save()}, the new data is
 *       written to that bean's znode.</li>
 *   <li>ZooKeeper notifies every other peer's watcher for that znode, which
 *       triggers this manager to call {@code configBean.load()} again on
 *       that peer - refreshing its in-memory state (and firing the usual
 *       {@code PropertyChangeListener}/{@code NodeChangeListener}
 *       notifications) - with no direct peer-to-peer coordination required.</li>
 * </ol>
 *
 * This class deliberately mirrors the style of {@link finalconfigclasses.cfg.Registry}
 * and {@link finalconfigclasses.cfg.LockManager} (private constructor + lazy
 * singleton holder).
 *
 * <h3>Bug fix: watches must be scoped to exactly one znode</h3>
 * {@link CuratorCache#build(CuratorFramework, String)} (no extra options)
 * caches - and fires listener callbacks for - the <b>entire ZooKeeper
 * subtree</b> rooted at the given path, not just that one znode. Because a
 * nested config bean's znode path is always a *child* of its parent bean's
 * znode path (see {@code ConfigBean._getXPath()} - a parent's xpath is
 * always a prefix of its children's), a parent bean's watcher was
 * incorrectly also firing (and re-triggering {@code parent.load()}) on
 * every change to any of its descendants' znodes. Combined with
 * {@link #watchSubtree(ConfigBean)} creating every descendant's znode via
 * {@code createContainers()} right at startup, this produced a cascade of
 * spurious reload tasks for every ancestor of every bean in the tree - all
 * funneled through the single {@code reloadExecutor} thread below. On any
 * non-trivial tree this can produce enough redundant, ZK-round-trip-bound
 * reload tasks to keep that single thread perpetually busy replaying stale
 * work, so that a *new*, real edit's reload task sits queued behind a large
 * and constantly-refilled backlog and never visibly "catches up" - which is
 * exactly what a change that "never seems to propagate again" looks like
 * from the outside, even though nothing actually deadlocked.
 *
 * The fix is two-fold:
 * <ol>
 *   <li>Build every bean's {@link CuratorCache} with
 *       {@link CuratorCache.Options#SINGLE_NODE_CACHE}, so it only ever
 *       watches that bean's own znode - never its descendants'.</li>
 *   <li>De-duplicate pending reload tasks per bean (a bean already queued
 *       for reload does not get queued a second time until that reload has
 *       actually run), so a burst of events for the same bean collapses
 *       into a single reload rather than piling up.</li>
 * </ol>
 */
public final class ZkConfigManager {

	private static final Logger LOG = Logger.getLogger(ZkConfigManager.class.getName());

	private static final class SingletonHolder {
		static final ZkConfigManager THE_ONE = new ZkConfigManager();
	}

	public static ZkConfigManager getInstance() {
		return SingletonHolder.THE_ONE;
	}

	private volatile CuratorFramework client;
	private final Object startLock = new Object();

	private final Map<ConfigBean, CuratorCache> watches = new IdentityHashMap<ConfigBean, CuratorCache>();
	private final Object watchLock = new Object();

	// Reload de-duplication: a bean already queued for reload is not queued
	// again until that reload has actually executed - collapses a burst of
	// redundant/overlapping ZooKeeper events for the same bean into one
	// reload instead of piling up N of them on the single reload thread.
	private final Set<ConfigBean> pendingReloads =
			java.util.Collections.newSetFromMap(new IdentityHashMap<ConfigBean, Boolean>());

	private final ExecutorService reloadExecutor = Executors.newSingleThreadExecutor(new ThreadFactory() {
		public Thread newThread(Runnable r) {
			Thread t = new Thread(r, "zk-config-reload");
			t.setDaemon(true);
			return t;
		}
	});

	private ZkConfigManager() {
	}

	/**
	 * Starts the shared ZooKeeper client using sane defaults (exponential
	 * back-off retry, 15s connect timeout). Safe to call multiple times -
	 * only the first call actually starts the client.
	 */
	public void start(String connectString) {
		start(connectString, new ExponentialBackoffRetry(1000, 3), 15000);
	}

	public void start(String connectString, RetryPolicy retryPolicy, int connectTimeoutMs) {
		if (client != null) {
			return;
		}
		synchronized (startLock) {
			if (client != null) {
				return;
			}
			CuratorFramework c = CuratorFrameworkFactory.newClient(connectString, retryPolicy);
			c.start();
			try {
				c.blockUntilConnected(connectTimeoutMs, TimeUnit.MILLISECONDS);
			} catch (InterruptedException ie) {
				Thread.currentThread().interrupt();
			}
			client = c;
		}
	}

	/**
	 * Allows an already-built/started CuratorFramework (e.g. one shared with
	 * other parts of the application, or configured with custom ACLs /
	 * authentication) to be plugged in instead of {@link #start(String)}.
	 */
	public void useClient(CuratorFramework externallyManagedClient) {
		if (externallyManagedClient == null) {
			throw new IllegalArgumentException("client is null");
		}
		this.client = externallyManagedClient;
	}

	public boolean isStarted() {
		return client != null;
	}

	public CuratorFramework getClient() {
		CuratorFramework c = client;
		if (c == null) {
			throw new IllegalStateException(
					"ZkConfigManager has not been started yet; call start(connectString) first.");
		}
		return c;
	}

	/**
	 * Registers a ZooKeeper watcher for a single config bean's znode. When
	 * the znode's data changes (from any peer, including this one) the bean
	 * is reloaded via {@code bean.load()} on a background thread. Idempotent:
	 * calling this again for the same bean instance is a no-op.
	 *
	 * The watcher is scoped to exactly this bean's own znode via
	 * {@link CuratorCache.Options#SINGLE_NODE_CACHE} - it does NOT also fire
	 * on changes to any nested/child beans' znodes, even though those live
	 * at deeper paths under this one. Watch each bean you care about
	 * individually (e.g. via {@link #watchSubtree}) rather than relying on
	 * a parent's watch to "cover" its children.
	 */
	public void watch(final ConfigBean bean) throws ConfigException {
		if (bean == null) {
			throw new IllegalArgumentException("bean is null");
		}
		final String znodePath = ZkConfigStore.buildZnodePath(bean._getPropertiesFile(), bean._getDocument(),
				bean._getXPath());
		synchronized (watchLock) {
			if (watches.containsKey(bean)) {
				return;
			}
			try {
				getClient().createContainers(znodePath);
			} catch (Exception ignoreExists) {
				// node may already exist - fine
			}
			CuratorCache cache = CuratorCache.build(getClient(), znodePath, CuratorCache.Options.SINGLE_NODE_CACHE);
			cache.listenable().addListener(CuratorCacheListener.builder()
					.forChanges((oldNode, newNode) -> scheduleReload(bean, znodePath))
					.forCreates(newNode -> scheduleReload(bean, znodePath))
					.build());
			cache.start();
			watches.put(bean, cache);
		}
	}

	/**
	 * Registers watchers for a bean and its entire subtree (all nested
	 * config beans reachable via properties), using the existing
	 * {@link finalconfigclasses.cfg.ConfigBeanVisitor} infrastructure. Each
	 * bean in the subtree gets its own, independently-scoped watch (see
	 * {@link #watch(ConfigBean)}) - a change to one bean's znode reloads
	 * only that bean, never its ancestors or descendants.
	 */
	public void watchSubtree(ConfigBean root) throws ConfigException {
		try {
			root.accept(new WatchAllVisitor(this));
		} catch (ConfigException ce) {
			throw ce;
		} catch (Exception e) {
			throw new ConfigException(e);
		}
	}

	/** Cancels the watcher for a single bean, if any. */
	public void unwatch(ConfigBean bean) {
		if (bean == null) {
			return;
		}
		CuratorCache cache;
		synchronized (watchLock) {
			cache = watches.remove(bean);
		}
		if (cache != null) {
			cache.close();
		}
	}

	/** Cancels watchers for a bean and its entire subtree. */
	public void unwatchSubtree(ConfigBean root) throws ConfigException {
		try {
			root.accept(new UnwatchAllVisitor(this));
		} catch (ConfigException ce) {
			throw ce;
		} catch (Exception e) {
			throw new ConfigException(e);
		}
	}

	private void scheduleReload(final ConfigBean bean, final String znodePath) {
		synchronized (pendingReloads) {
			if (!pendingReloads.add(bean)) {
				// a reload for this exact bean is already queued/running - the
				// pending one will pick up the latest data anyway once it runs,
				// so there is no need (and no benefit) to queue a second one.
				return;
			}
		}
		reloadExecutor.submit(() -> {
			try {
				bean.load();
			} catch (ConfigException ce) {
				LOG.log(Level.WARNING, "Failed to reload config bean after ZooKeeper change at " + znodePath, ce);
			} catch (RuntimeException re) {
				LOG.log(Level.WARNING, "Unexpected error reloading config bean after ZooKeeper change at "
						+ znodePath, re);
			} finally {
				synchronized (pendingReloads) {
					pendingReloads.remove(bean);
				}
			}
		});
	}

	/**
	 * Stops all watchers, shuts down the reload executor and (if this
	 * manager owns the CuratorFramework instance, i.e. it was created via
	 * {@link #start(String)} rather than {@link #useClient(CuratorFramework)})
	 * closes the ZooKeeper client. Intended for orderly application shutdown.
	 */
	public void shutdown() {
		synchronized (watchLock) {
			for (CuratorCache cache : watches.values()) {
				cache.close();
			}
			watches.clear();
		}
		synchronized (pendingReloads) {
			pendingReloads.clear();
		}
		reloadExecutor.shutdown();
		CuratorFramework c = client;
		if (c != null) {
			c.close();
			client = null;
		}
	}
}
